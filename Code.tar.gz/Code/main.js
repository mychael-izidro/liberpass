const { app, BrowserWindow } = require('electron')

function createWindow () {
  // Cria uma janela de navegação.
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    icon: './img/logo.png',
    webPreferences: {
      nodeIntegration: true,
      devTools: false
    },
    minWidth:800,
    minHeight:600,
    maxWidth:800,
    minHeight:600
  })
  win.setMenu(null)
  // e carrega o arquivo index.html do seu aplicativo.
  win.loadFile('index.html')
}

app.whenReady().then(createWindow)
