var copy = () =>{
    var text = document.getElementById('campo');
        text.select();
        document.execCommand('copy');
    setInterval(contar, 1000);
    document.getElementById('ntf').innerText = 'Copied text!';
    var contador = 3;
    function contar() {
        contador--;
        if (contador == 0) {
        document.getElementById('ntf').innerText = '';
        contador = undefined;
        }
    }
};
var btn = () =>{
    var tipo = document.getElementById('tipo').value;
    if(tipo == 0){ 
    let num = Math.random().toString(10);
    let fn = (Number(num) * 10000000000).toFixed(0);
    document.getElementById('campo').value = `${fn}`;
    }
    if(tipo == 1){
        let num = (Math.random().toString(36)).slice(2,50);
    document.getElementById('campo').value = `${num}`;
    }
    else if(tipo == 2){
        let num = (Math.random().toString(2)).slice(2,50);
        document.getElementById('campo').value = `${num}`;
    }
}
